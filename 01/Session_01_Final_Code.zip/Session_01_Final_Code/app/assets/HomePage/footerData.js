export const footerData = [
    {
      title: "StockTracker Pro",
      items: "Powerful stock market analysis tools for investors of all levels.",
    },
    {
      title: "Features",
      items: ["Dashboard", "Watchlist", "Portfolio"],
    },
    {
      title: "Account",
      items: ["Sign In", "Create Account"],
    },
    {
      title: "Legal",
      items: ["Terms of Service", "Privacy Policy", "Disclaimer"],
    },
];
  